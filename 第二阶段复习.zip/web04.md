# 回顾

1.git   push   发现与别人修改的代码有冲突

2.git   pull	将线上的代码拉取到本地

3.git    status	找到冲突文件都有些，冲突文件的状态是：both  modified

4.逐一打开冲突文件，逐行进行解决

5.冲突代码解决后，将代码中冲突标记删除

6.git	add  ./

7.git    commit -m  解决冲突，进行了一次合并

8.git  push



# 分支：

git	branch 	分支名       创建分支

git checkout 	分支名

git checkout   -b  分支名		切换并同时创建分支名